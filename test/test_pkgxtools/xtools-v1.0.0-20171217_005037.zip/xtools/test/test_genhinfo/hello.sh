#!/bin/bash

echo "hello world and hello me!"
