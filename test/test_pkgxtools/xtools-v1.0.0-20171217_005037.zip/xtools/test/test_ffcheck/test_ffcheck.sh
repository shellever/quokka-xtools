#!/bin/bash

############################################################
# Author: Shellever
# Date:   11/25/2017 23:32:53
# Desc:   check the file format
# Email:  shellever@163.com
# Usage: 
# History: 
############################################################

# Windows
ffcheck ./hello_win.sh

# Unix
ffcheck ./hello_unix.sh

