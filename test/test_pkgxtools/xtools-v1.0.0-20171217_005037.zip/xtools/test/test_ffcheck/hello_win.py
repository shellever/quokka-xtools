#!/usr/bin/env python

print "Hello world and hello me"
