#!/bin/bash

echo "Hello world and hello me"
