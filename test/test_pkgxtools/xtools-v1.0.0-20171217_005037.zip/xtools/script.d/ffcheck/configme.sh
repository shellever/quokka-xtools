ln -s /home/linuxfor/Documents/xtools/script.d/ffcheck/file-format-check.sh $PATH_XTOOLS/link.d/ffcheck
