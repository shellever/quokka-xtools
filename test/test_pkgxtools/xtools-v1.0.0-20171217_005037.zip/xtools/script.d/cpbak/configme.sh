ln -s $PATH_XTOOLS/script.d/cpbak/cp-with-backup.sh $PATH_XTOOLS/link.d/cpbak
