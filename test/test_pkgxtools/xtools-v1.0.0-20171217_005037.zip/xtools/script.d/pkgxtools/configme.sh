ln -s /home/linuxfor/Documents/xtools/script.d/pkgxtools/package-xtools.sh $PATH_XTOOLS/link.d/pkgxtools
