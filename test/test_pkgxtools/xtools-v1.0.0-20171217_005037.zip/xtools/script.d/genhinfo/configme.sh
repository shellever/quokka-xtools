ln -s $PATH_XTOOLS/script.d/genhinfo/gen-header-info.sh $PATH_XTOOLS/link.d/genhinfo
